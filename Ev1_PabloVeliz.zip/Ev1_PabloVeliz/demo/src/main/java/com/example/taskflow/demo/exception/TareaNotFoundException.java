package com.example.taskflow.demo.exception;

public class TareaNotFoundException extends RuntimeException {
    
    public TareaNotFoundException(int id) {
        super("Tarea con id " + id + " no encontrado/a");
    }

}