package com.example.taskflow.demo.repository;
import java.util.ArrayList;
import java.util.List;

import com.example.taskflow.demo.model.Tarea;
import org.springframework.stereotype.Repository;

@Repository
public class TareasRepository{

    private List<Tarea> listaTareas = new ArrayList<>();

    public TareasRepository(){
        listaTareas.add(new Tarea(1,"Limpiar", true, "alta", "Encargado limpieza", "12/04/2026"));
        listaTareas.add(new Tarea(2,"Proyecto full stack", true, "alta", "Estudiante 01", "15/04/2026"));
    }

    //Consultar tareas existentes}

    public List<Tarea> obtenerTareas(){
        return listaTareas;
    }

    //Registrar tareas nuevas
    public Tarea guardar(Tarea tarea){
        listaTareas.add(tarea);
        return tarea ;
    }

    //Actualizar tareas
    public Tarea actualizar(Tarea tarea){
        int idPosicion = 0;
        for ( int i = 0; i < listaTareas.size(); i++){
            if(listaTareas.get(i).getId() == tarea.getId()){
                idPosicion = i ;
            }
        }
        listaTareas.set(idPosicion, tarea);
        return tarea;
    }

    //Eliminar tareas
    public void eliminar(int id){
        listaTareas.removeIf(t -> t.getId() == id); }

    //Obtener tareas activas
    public List<Tarea> obtenerActivos(){

        List<Tarea> activos = new ArrayList<>();
        for (Tarea t : listaTareas){
            if(t.isActivo()){
                activos.add(t);
            }
        }
        return activos;
    }
}



        

