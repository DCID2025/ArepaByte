package com.example.taskflow.demo.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Tarea {


    private int id;
    
    @NotBlank(message = "Descripcion obligatoria")
    private String descripcion;

    @NotNull(message = "Estado obligatorio")
    private boolean activo;

    @NotBlank(message = "Prioridad obligatoria")
    private String prioridad; 

    @NotBlank(message = "Rol obligatorio")
    private String responsable;

    private String fechas;
}
