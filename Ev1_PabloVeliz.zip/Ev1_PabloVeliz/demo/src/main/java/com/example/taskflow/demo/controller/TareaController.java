package com.example.taskflow.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.*;

import com.example.taskflow.demo.Service.TareaService;
import com.example.taskflow.demo.model.Tarea;

@RestController
@RequestMapping("/api/v1/tareas")
public class TareaController {

    @Autowired
    private TareaService tareaService;

    //Listar tareas
    @GetMapping 
    public List<Tarea> listarTareas(){
        return tareaService.getTareas();
    }

    //Listar tareas activas
    @GetMapping("/activos")
    public List<Tarea> listarActivos(){
        return tareaService.getTareasActivo();
    }

    //Actualizar tareas
    @PutMapping("{id}")
    public Tarea actualizTarea(@PathVariable int id, @RequestBody Tarea tarea){
        tarea.setId(id);
        return tareaService.updateTarea(tarea);
    }

    //Crear tarea
    @PostMapping
    public Tarea crearTarea(@RequestBody Tarea tarea){
        return tareaService.saveTarea(tarea);
    }

    //eliminar
    @DeleteMapping("{id}")
    public String eliminarTarea(@PathVariable int id){
        return tareaService.deleteTarea(id);

    }


}
