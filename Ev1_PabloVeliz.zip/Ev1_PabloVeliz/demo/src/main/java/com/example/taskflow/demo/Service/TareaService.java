package com.example.taskflow.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.taskflow.demo.model.Tarea;
import com.example.taskflow.demo.repository.TareasRepository;

@Service
public class TareaService {
    @Autowired
    private TareasRepository tareasRepository;
    public List<Tarea> getTareas(){
        return tareasRepository.obtenerTareas();
    }

    public List<Tarea> getTareasActivo(){
        return tareasRepository.obtenerActivos();
    }

    public Tarea saveTarea(Tarea tarea){
        return tareasRepository.guardar(tarea);
    }

    public Tarea updateTarea(Tarea tarea){
        return tareasRepository.actualizar(tarea);
    }

    public String deleteTarea(int id){
        tareasRepository.eliminar(id);
        return "Tarea eliminada";
    }

    public int totalTareas(){
        return tareasRepository.obtenerTareas().size();
    
    }
}
